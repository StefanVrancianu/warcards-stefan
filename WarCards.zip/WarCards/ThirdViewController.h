//
//  ThirdViewController.h
//  WarCards
//
//  Created by Stefan Vrancianu on 17/12/15.
//  Copyright © 2015 Stefan Vrancianu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController

@property (nonatomic) NSInteger iValueToReceive3;
@property (weak, nonatomic) NSString *iKindToReceive3;

@property (nonatomic) NSInteger ihandsPlayed3;
@property (nonatomic) NSInteger ihandsOwned3;

@end
