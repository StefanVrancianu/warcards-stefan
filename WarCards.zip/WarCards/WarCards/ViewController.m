//
//  ViewController.m
//  WarCards
//
//  Created by Stefan Vrancianu on 16/12/15.
//  Copyright © 2015 Stefan Vrancianu. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
#import "PlayersViewController.h"
#import "Card.h"

static NSString *kDeckArrayKey = @"keyDeckArray";
static NSString *kDeckRandomKey = @"keyDeckRandom";
static NSString *kStatePlayerOneKey = @"kForStateOfPlayerOneKey";
static NSString *kStatePlayerTwoKey = @"kForStateOfPlayerTwoKey";

@interface ViewController ()

@property (strong, nonatomic) IBOutlet UIView *viewC;
@property (weak, nonatomic) IBOutlet UIImageView *PlayerTwoCard;
@property (weak, nonatomic) IBOutlet UIImageView *PlayerOneCard;
@property (weak, nonatomic) IBOutlet UILabel *ScorePlayerTwo;
@property (weak, nonatomic) IBOutlet UILabel *ScorePlayerOne;
@property (strong, nonatomic) NSMutableArray *Deck;
@property (strong, nonatomic) NSMutableArray *RandDeck;
@property (strong, nonatomic) NSMutableArray *PlayerOneDeck;
@property (strong, nonatomic) NSMutableArray *PlayerTwoDeck;
@property (strong, nonatomic) NSMutableArray *rememberingDeck1;
@property (strong, nonatomic) NSMutableArray *rememberingDeck2;



@end

@implementation ViewController

@synthesize iPlayerOneName;
@synthesize iPlayerTwoName;
@synthesize playerOneNameLabel;
@synthesize playerTwoNameLabel;

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"gotoSecond"]){
        
        SecondViewController *svc = segue.destinationViewController;
        svc.ihandsPlayed = self.numOfHands;
        svc.ihandsOwned  = self.handsWonbyPlayerOne;
        svc.iValueToReceive = [[self.rememberingDeck2 lastObject] valueOfCard];
        svc.iKindToReceive = [[self.rememberingDeck2 lastObject] kind];
        
    }
    else if([segue.identifier isEqualToString:@"gotoThird"]) {
        ThirdViewController *tvc = segue.destinationViewController;
        tvc.ihandsPlayed3 = self.numOfHands;
        tvc.ihandsOwned3 = self.handsWonbyPlayerTwo;
        tvc.iValueToReceive3 = [[self.rememberingDeck1 lastObject] valueOfCard];
        tvc.iKindToReceive3 = [[self.rememberingDeck1 lastObject] kind];
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
//    if([[NSUserDefaults standardUserDefaults] objectForKey:@"keyDeckArray"] != nil){
//        [self saveStateOfTheGame:(NSNotification *) @"saveStateOfGame"];
//    }
//    else {
//        [self makeDeck];
//        [self shuffleDeck];
//    }
    
    [self makeDeck];
    [self shuffleDeck];
    
    self.PlayerOneCard.image = [UIImage imageNamed: [NSString stringWithFormat:@"%ld_%@", (long)[[self.PlayerOneDeck lastObject] valueOfCard ] , [[self.PlayerOneDeck objectAtIndex:0] kind]]];
    
    self.PlayerTwoCard.image = [UIImage imageNamed: [NSString stringWithFormat:@"%ld_%@", (long)[[self.PlayerTwoDeck lastObject] valueOfCard ] , [[self.PlayerTwoDeck objectAtIndex:0] kind]]];
    
    [self.playerOneNameLabel setText:iPlayerOneName];
    [self.playerTwoNameLabel setText:iPlayerTwoName];

    
    self.rememberingDeck1 = [NSMutableArray arrayWithCapacity:52];
    self.rememberingDeck2 = [NSMutableArray arrayWithCapacity:52];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(saveStateOfTheGame:)
                                                 name:@"saveStateOfGame"
                                               object:nil];

    
}

- (void) makeDeck {
    
    //      Crearea pachetului de carti (Deck)      //
    
    
    self.Deck = [NSMutableArray arrayWithCapacity:52];
    for(int i = 1; i <= 52; i++)
    {
        Card *card = [[Card alloc] init];
        if(i<=13)
        {
            [card initCard:i withKind:@"trefla"];
        }
        else if(i>13 && i<= 26)
        {
            [card initCard:i-13 withKind:@"rosu"];
        }
        else if(i>26 && i<=39)
        {
            [card initCard:i-26 withKind:@"negru"];
        }
        else if(i>39)
        {
            [card initCard:i-39 withKind:@"caro"];
        }
        [self.Deck addObject:card];
        
        
    }

    
}

- (void) shuffleDeck {
    
    //      Amestecarea pachetului de carti si impartirea lui in doua jumatati egale        //
    
    
    NSUInteger count = [self.Deck count];
    if (count > 1)
    {
        for (NSUInteger i = count - 1; i > 0; --i)
        {
            [self.Deck exchangeObjectAtIndex:i withObjectAtIndex:arc4random_uniform((int32_t)(i + 1))];
        }
    }
    
    self.RandDeck  = [NSMutableArray arrayWithArray:self.Deck];
    self.PlayerOneDeck = [NSMutableArray arrayWithCapacity:52];
    self.PlayerTwoDeck = [NSMutableArray arrayWithCapacity:52];
    for(NSUInteger i = 0; i < [self.RandDeck count]; i++)
    {
        if(i < [self.RandDeck count]/2)
        {
            [self.PlayerOneDeck addObject:[self.RandDeck objectAtIndex:i]];
        }
        else
        {
            [self.PlayerTwoDeck addObject:[self.RandDeck objectAtIndex:i]];
        }
        
    }

    
}

- (void) saveStateOfTheGame: (NSNotification *)notification {
    
    // Retrieve object, if any from user defaults.
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    id result = [userDefaults objectForKey: kDeckArrayKey];
    
    if (!result) {  // No data stored.
        [userDefaults setObject:[NSKeyedArchiver archivedDataWithRootObject:self.Deck] forKey: kDeckArrayKey];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else {  // Data already stored. Retrieve and print it.
        self.Deck = [NSKeyedUnarchiver unarchiveObjectWithData: result];
        
    }
    
    
    // Retrieve object, if any from user defaults.
    NSUserDefaults *userDefaults1 = [NSUserDefaults standardUserDefaults];
    id result1 = [userDefaults1 objectForKey: kStatePlayerOneKey];
    
    if (!result1) {  // No data stored.
        [userDefaults1 setObject:[NSKeyedArchiver archivedDataWithRootObject:self.PlayerOneDeck] forKey: kStatePlayerOneKey];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else {  // Data already stored. Retrieve and print it.
        self.PlayerOneDeck = [NSKeyedUnarchiver unarchiveObjectWithData: result1];
        
    }
    
    // Retrieve object, if any from user defaults.
    NSUserDefaults *userDefaults2 = [NSUserDefaults standardUserDefaults];
    id result2 = [userDefaults2 objectForKey: kStatePlayerTwoKey];
    
    if (!result2) {  // No data stored.
        [userDefaults2 setObject:[NSKeyedArchiver archivedDataWithRootObject:self.PlayerTwoDeck] forKey: kStatePlayerTwoKey];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else {  // Data already stored. Retrieve and print it.
        self.PlayerTwoDeck = [NSKeyedUnarchiver unarchiveObjectWithData: result2];
        
    }
    
    // Retrieve object, if any from user defaults.
    NSUserDefaults *userDefaults3 = [NSUserDefaults standardUserDefaults];
    id result3 = [userDefaults3 objectForKey: kDeckRandomKey];
    
    if (!result3) {  // No data stored.
        [userDefaults3 setObject:[NSKeyedArchiver archivedDataWithRootObject:self.RandDeck] forKey: kDeckRandomKey];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else {  // Data already stored. Retrieve and print it.
        self.RandDeck = [NSKeyedUnarchiver unarchiveObjectWithData: result3];
        
    }

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonOfWar:(id)sender {
    
    NSString *alertMessege;
    
    
    if([self.PlayerOneDeck count] > 0 && [self.PlayerTwoDeck count] > 0)
    {
        self.PlayerOneCard.image = [UIImage imageNamed: [NSString stringWithFormat:@"%ld_%@", (long)[[self.PlayerOneDeck objectAtIndex:0] valueOfCard ] , [[self.PlayerOneDeck objectAtIndex:0] kind]]];
        
        self.PlayerTwoCard.image = [UIImage imageNamed: [NSString stringWithFormat:@"%ld_%@", (long)[[self.PlayerTwoDeck objectAtIndex:0] valueOfCard ] , [[self.PlayerTwoDeck objectAtIndex:0] kind]]];
        
        
        [self.ScorePlayerOne setText:[NSString stringWithFormat:@"Score: %ld", [self.PlayerOneDeck count]]];
        [self.ScorePlayerTwo setText:[NSString stringWithFormat:@"Score: %ld", [self.PlayerTwoDeck count]]];
        
        if([[self.PlayerOneDeck objectAtIndex:0] valueOfCard] < [[self.PlayerTwoDeck objectAtIndex:0] valueOfCard])
        {
            [self.rememberingDeck1 addObject:[self.PlayerOneDeck objectAtIndex:0]];
            [self.rememberingDeck2 addObject:[self.PlayerTwoDeck objectAtIndex:0]];
            [self.PlayerTwoDeck addObject:[self.PlayerOneDeck objectAtIndex:0]];
            [self.PlayerOneDeck removeObjectAtIndex:0];
            [self.PlayerTwoDeck addObject:[self.PlayerTwoDeck objectAtIndex:0]];
            [self.PlayerTwoDeck removeObjectAtIndex:0];
            self.handsWonbyPlayerOne++;
        }
        else
        {
            [self.rememberingDeck1 addObject:[self.PlayerOneDeck objectAtIndex:0]];
            [self.rememberingDeck2 addObject:[self.PlayerTwoDeck objectAtIndex:0]];
            [self.PlayerOneDeck addObject:[self.PlayerTwoDeck objectAtIndex:0]];
            [self.PlayerTwoDeck removeObjectAtIndex:0];
            [self.PlayerOneDeck addObject:[self.PlayerOneDeck objectAtIndex:0]];
            [self.PlayerOneDeck removeObjectAtIndex:0];
            self.handsWonbyPlayerTwo++;
        }
        
    }
    else
    {
        if( [self.PlayerOneDeck count] == 0)
            alertMessege = @"Player Two Wins !";
        else if([self.PlayerTwoDeck count] == 0)
            alertMessege = @"Player One Wins !";
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Game" message:alertMessege preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {}];
        
        [alert addAction:okAction];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        
    }
    self.numOfHands++;
    
    
}


@end
