//
//  PlayersViewController.m
//  WarCards
//
//  Created by Stefan Vrancianu on 21/12/15.
//  Copyright © 2015 Stefan Vrancianu. All rights reserved.
//

#import "PlayersViewController.h"
#import "ViewController.h"



@interface PlayersViewController ()


@end

@implementation PlayersViewController

@synthesize playerOneNameTextField;
@synthesize playerTwoNameTextField;

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"gotoFirstViewController"]) {
        ViewController *vc = segue.destinationViewController;
        vc.iPlayerOneName = playerOneNameTextField.text;
        vc.iPlayerTwoName = playerTwoNameTextField.text;
    }
    
}

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [self.playerOneNameTextField resignFirstResponder];
    [self.playerTwoNameTextField resignFirstResponder];
    
    
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.playerOneNameTextField.delegate = self;
    self.playerTwoNameTextField.delegate = self;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)submitNamesButton:(id)sender {
    
    [self performSegueWithIdentifier:@"gotoFirstViewController" sender:self];
    
}

@end
